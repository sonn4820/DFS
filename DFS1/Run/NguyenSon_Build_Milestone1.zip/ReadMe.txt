How to use:

F1 toggle debug draw
F2 to change mode

Mouse mode: Use mouse to aim, hold space to increase force

Debug mode: 
- Scroll to select option 
- Q/E to adjust value 
- Space to shoot
- R to reset all stats to 0

J to reset ball to origin





